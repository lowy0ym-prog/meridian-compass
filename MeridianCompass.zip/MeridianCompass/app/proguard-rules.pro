# Keep Room entities
-keep class com.meridian.compass.data.** { *; }
