package com.meridian.compass

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.meridian.compass.settings.ThemePreference
import com.meridian.compass.ui.screens.AddEditWaypointScreen
import com.meridian.compass.ui.screens.CompassScreen
import com.meridian.compass.ui.screens.SettingsScreen
import com.meridian.compass.ui.screens.WaypointListScreen
import com.meridian.compass.ui.theme.AppThemeMode
import com.meridian.compass.ui.theme.MeridianTheme
import com.meridian.compass.viewmodel.CompassViewModel
import com.meridian.compass.viewmodel.WaypointViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val compassViewModel: CompassViewModel by viewModels()
    private val waypointViewModel: WaypointViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants.values.any { it }
        if (granted) {
            compassViewModel.beginLocationUpdates()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val app = application as MeridianApplication
            val settings by app.settingsRepository.settingsFlow.collectAsState(
                initial = com.meridian.compass.settings.AppSettings()
            )

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(Unit) {
                requestLocationPermissionIfNeeded()
            }

            val themeMode = when (settings.theme) {
                ThemePreference.LIGHT -> AppThemeMode.LIGHT
                ThemePreference.DARK -> AppThemeMode.DARK
                ThemePreference.SYSTEM -> AppThemeMode.SYSTEM
            }

            MeridianTheme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppNavHost(compassViewModel, waypointViewModel)
                }
            }
        }
    }

    private fun requestLocationPermissionIfNeeded() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fineGranted || coarseGranted) {
            compassViewModel.beginLocationUpdates()
        } else {
            requestPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppNavHost(compassViewModel: CompassViewModel, waypointViewModel: WaypointViewModel) {
    val navController = rememberNavController()
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        compassViewModel.startSensors()
        onDispose { compassViewModel.stopSensors() }
    }

    // Sun/moon positions and rise/set times depend on wall-clock time; refresh periodically
    // so they drift correctly over the course of the day without needing a sensor event.
    LaunchedEffect(Unit) {
        while (true) {
            compassViewModel.refreshCelestialClock()
            kotlinx.coroutines.delay(30_000L)
        }
    }

    val uiState by compassViewModel.uiState.collectAsState()
    val waypoints by waypointViewModel.waypoints.collectAsState()
    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as MeridianApplication
    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()

    var editingWaypointId by remember { mutableStateOf<Long?>(null) }

    NavHost(navController = navController, startDestination = "compass") {
        composable("compass") {
            CompassScreen(
                uiState = uiState,
                onToggleNorthReference = {
                    val next = if (uiState.settings.northReference == com.meridian.compass.settings.NorthReference.TRUE)
                        com.meridian.compass.settings.NorthReference.MAGNETIC
                    else com.meridian.compass.settings.NorthReference.TRUE
                    coroutineScope.launch { app.settingsRepository.setNorthReference(next) }
                },
                onOpenWaypoints = { navController.navigate("waypoints") },
                onOpenSettings = { navController.navigate("settings") },
                onClearTarget = { compassViewModel.selectWaypoint(null) }
            )
        }
        composable("waypoints") {
            WaypointListScreen(
                waypoints = waypoints,
                currentLat = uiState.location.latitude,
                currentLon = uiState.location.longitude,
                distanceUnit = uiState.settings.distanceUnit,
                onBack = { navController.popBackStack() },
                onAddNew = {
                    editingWaypointId = null
                    navController.navigate("waypointEdit")
                },
                onEdit = { wp ->
                    editingWaypointId = wp.id
                    navController.navigate("waypointEdit")
                },
                onDelete = { wp -> waypointViewModel.delete(wp) },
                onSelect = { wp ->
                    compassViewModel.selectWaypoint(wp)
                    navController.navigate("compass") { popUpTo("compass") { inclusive = true } }
                }
            )
        }
        composable("waypointEdit") {
            val existing = waypoints.find { it.id == editingWaypointId }
            AddEditWaypointScreen(
                existing = existing,
                currentLat = uiState.location.latitude,
                currentLon = uiState.location.longitude,
                currentAltitude = uiState.location.bestAltitudeMeters,
                onBack = { navController.popBackStack() },
                onSave = { name, lat, lon, altitude ->
                    if (existing == null) {
                        waypointViewModel.saveNew(name, lat, lon, altitude, null)
                    } else {
                        waypointViewModel.update(existing.copy(name = name, latitude = lat, longitude = lon, altitudeMeters = altitude))
                    }
                    navController.popBackStack()
                }
            )
        }
        composable("settings") {
            SettingsScreen(
                settings = uiState.settings,
                onBack = { navController.popBackStack() },
                onNorthReferenceChange = { coroutineScope.launch { app.settingsRepository.setNorthReference(it) } },
                onDistanceUnitChange = { coroutineScope.launch { app.settingsRepository.setDistanceUnit(it) } },
                onAltitudeUnitChange = { coroutineScope.launch { app.settingsRepository.setAltitudeUnit(it) } },
                onHapticEnabledChange = { coroutineScope.launch { app.settingsRepository.setHapticEnabled(it) } },
                onHapticStepChange = { coroutineScope.launch { app.settingsRepository.setHapticStepDegrees(it) } },
                onThemeChange = { coroutineScope.launch { app.settingsRepository.setTheme(it) } },
                onKeepScreenOnChange = { coroutineScope.launch { app.settingsRepository.setKeepScreenOn(it) } }
            )
        }
    }
}
