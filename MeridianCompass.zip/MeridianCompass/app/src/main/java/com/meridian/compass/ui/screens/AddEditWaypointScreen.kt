package com.meridian.compass.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.meridian.compass.data.Waypoint

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AddEditWaypointScreen(
    existing: Waypoint?,
    currentLat: Double?,
    currentLon: Double?,
    currentAltitude: Double?,
    onBack: () -> Unit,
    onSave: (name: String, lat: Double, lon: Double, altitude: Double?) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var latText by remember { mutableStateOf((existing?.latitude ?: currentLat ?: 0.0).toString()) }
    var lonText by remember { mutableStateOf((existing?.longitude ?: currentLon ?: 0.0).toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "New Waypoint" else "Edit Waypoint") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
            androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))
            OutlinedTextField(
                value = latText,
                onValueChange = { latText = it },
                label = { Text("Latitude") },
                modifier = Modifier.fillMaxWidth()
            )
            androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))
            OutlinedTextField(
                value = lonText,
                onValueChange = { lonText = it },
                label = { Text("Longitude") },
                modifier = Modifier.fillMaxWidth()
            )
            error?.let {
                androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))
                Text(it, color = androidx.compose.material3.MaterialTheme.colorScheme.error)
            }
            androidx.compose.foundation.layout.Spacer(Modifier.padding(12.dp))
            Button(
                onClick = {
                    val lat = latText.toDoubleOrNull()
                    val lon = lonText.toDoubleOrNull()
                    when {
                        name.isBlank() -> error = "Please enter a name."
                        lat == null || lat < -90 || lat > 90 -> error = "Latitude must be between -90 and 90."
                        lon == null || lon < -180 || lon > 180 -> error = "Longitude must be between -180 and 180."
                        else -> {
                            onSave(name.trim(), lat, lon, existing?.altitudeMeters ?: currentAltitude)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Waypoint")
            }
            if (existing == null && currentLat != null) {
                androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))
                Text(
                    "Prefilled with your current location — edit if needed.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }
    }
}
