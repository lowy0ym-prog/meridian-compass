package com.meridian.compass.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meridian.compass.astronomy.MoonInfo
import com.meridian.compass.astronomy.SunInfo
import com.meridian.compass.sensors.CompassAccuracy
import com.meridian.compass.settings.AltitudeUnit
import com.meridian.compass.settings.DistanceUnit
import com.meridian.compass.settings.NorthReference
import com.meridian.compass.ui.components.CompassDial
import com.meridian.compass.ui.components.DialMarker
import com.meridian.compass.util.Bearing
import com.meridian.compass.viewmodel.CompassUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CompassScreen(
    uiState: CompassUiState,
    onToggleNorthReference: () -> Unit,
    onOpenWaypoints: () -> Unit,
    onOpenSettings: () -> Unit,
    onClearTarget: () -> Unit
) {
    val bg = MaterialTheme.colorScheme.background
    val onBg = MaterialTheme.colorScheme.onBackground
    val accent = MaterialTheme.colorScheme.primary

    Surface(color = bg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(PaddingValues(horizontal = 20.dp, vertical = 16.dp))
        ) {
            TopBar(onOpenWaypoints, onOpenSettings)

            Spacer(Modifier.height(4.dp))

            AccuracyBanner(uiState.orientation.accuracy, uiState.orientation.magneticInterferenceSuspected)

            Spacer(Modifier.height(8.dp))

            HeadingReadout(
                headingDegrees = uiState.displayHeadingDegrees,
                northReference = uiState.settings.northReference,
                onToggleNorthReference = onToggleNorthReference
            )

            Spacer(Modifier.height(4.dp))

            val markers = buildList {
                uiState.sunInfo?.let {
                    add(DialMarker(it.position.azimuthDegrees, Color(0xFFFFC94A), "S", it.position.elevationDegrees))
                }
                uiState.moonInfo?.let {
                    add(DialMarker(it.position.azimuthDegrees, Color(0xFFB9C4D9), "M", it.position.elevationDegrees))
                }
            }

            CompassDial(
                headingDegrees = uiState.displayHeadingDegrees,
                targetBearingDegrees = uiState.bearingToWaypointDegrees,
                markers = markers,
                ringColor = onBg.copy(alpha = 0.6f),
                dialBackground = MaterialTheme.colorScheme.surface,
                textColor = onBg,
                accentColor = accent,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Spacer(Modifier.height(8.dp))

            if (uiState.selectedWaypoint != null) {
                TargetCard(
                    name = uiState.selectedWaypoint.name,
                    bearing = uiState.bearingToWaypointDegrees,
                    distanceMeters = uiState.distanceToWaypointMeters,
                    unit = uiState.settings.distanceUnit,
                    onClear = onClearTarget
                )
                Spacer(Modifier.height(10.dp))
            }

            InfoGrid(uiState)

            Spacer(Modifier.height(10.dp))

            SunMoonRow(uiState.sunInfo, uiState.moonInfo)
        }
    }
}

@Composable
private fun TopBar(onOpenWaypoints: () -> Unit, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Meridian", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
        Row {
            IconButton(onClick = onOpenWaypoints) {
                Icon(Icons.Filled.List, contentDescription = "Waypoints", tint = MaterialTheme.colorScheme.onBackground)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onBackground)
            }
        }
    }
}

@Composable
private fun AccuracyBanner(accuracy: CompassAccuracy, interference: Boolean) {
    val show = accuracy == CompassAccuracy.UNRELIABLE || accuracy == CompassAccuracy.LOW || interference
    if (!show) return
    val message = when {
        interference && accuracy != CompassAccuracy.HIGH -> "Magnetic interference detected — move away from metal or electronics"
        accuracy == CompassAccuracy.UNRELIABLE -> "Compass needs calibration — move phone in a figure-8"
        else -> "Low compass accuracy — calibration recommended"
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(8.dp))
        Text(message, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
    }
}

@Composable
private fun HeadingReadout(headingDegrees: Float, northReference: NorthReference, onToggleNorthReference: () -> Unit) {
    val pointLabel = Bearing.compassPointLabel(headingDegrees.toDouble())
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "${headingDegrees.toInt()}°",
            style = MaterialTheme.typography.displayLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = pointLabel,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
        )
        Spacer(Modifier.height(6.dp))
        Surface(
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.clickable { onToggleNorthReference() }
        ) {
            Text(
                text = if (northReference == NorthReference.TRUE) "TRUE NORTH" else "MAGNETIC NORTH",
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun TargetCard(
    name: String,
    bearing: Double?,
    distanceMeters: Double?,
    unit: DistanceUnit,
    onClear: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(
                    text = buildString {
                        bearing?.let { append("${it.toInt()}°  ") }
                        distanceMeters?.let { append(formatDistance(it, unit)) }
                    },
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Text(
                "Clear",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onClear() }
            )
        }
    }
}

@Composable
private fun InfoGrid(uiState: CompassUiState) {
    val loc = uiState.location
    val unit = uiState.settings.distanceUnit
    val altUnit = uiState.settings.altitudeUnit

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            InfoRow("Latitude", loc.latitude?.let { formatCoordinate(it, isLat = true) } ?: "—")
            InfoRow("Longitude", loc.longitude?.let { formatCoordinate(it, isLat = false) } ?: "—")
            InfoRow(
                "Altitude",
                loc.bestAltitudeMeters?.let { formatAltitude(it, altUnit) + if (loc.altitudeIsRoughEstimate) " (est.)" else "" } ?: "—"
            )
            InfoRow("GPS accuracy", loc.horizontalAccuracyMeters?.let { "±${it.toInt()} m" } ?: "—")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun SunMoonRow(sun: SunInfo?, moon: MoonInfo?) {
    val fmt = remember_time_formatter()
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text("☀ Sun", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Text(
                text = "${sun?.sunriseMillis?.let { fmt.format(Date(it)) } ?: "—"} / ${sun?.sunsetMillis?.let { fmt.format(Date(it)) } ?: "—"}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = sun?.let { "elev ${it.position.elevationDegrees.toInt()}°" } ?: "",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f)
            )
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("☾ Moon", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Text(
                text = "${moon?.moonriseMillis?.let { fmt.format(Date(it)) } ?: "—"} / ${moon?.moonsetMillis?.let { fmt.format(Date(it)) } ?: "—"}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = moon?.let { "${it.phaseName} · ${(it.illuminationFraction * 100).toInt()}%" } ?: "",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f)
            )
        }
    }
}

@Composable
private fun remember_time_formatter(): SimpleDateFormat =
    androidx.compose.runtime.remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

private fun formatCoordinate(value: Double, isLat: Boolean): String {
    val hemi = if (isLat) (if (value >= 0) "N" else "S") else (if (value >= 0) "E" else "W")
    return String.format(Locale.US, "%.5f° %s", kotlin.math.abs(value), hemi)
}

private fun formatAltitude(meters: Double, unit: AltitudeUnit): String = when (unit) {
    AltitudeUnit.METERS -> "${meters.toInt()} m"
    AltitudeUnit.FEET -> "${Bearing.metersToFeet(meters).toInt()} ft"
}

private fun formatDistance(meters: Double, unit: DistanceUnit): String = when (unit) {
    DistanceUnit.METRIC -> if (meters >= 1000) String.format(Locale.US, "%.2f km", Bearing.metersToKilometers(meters)) else "${meters.toInt()} m"
    DistanceUnit.IMPERIAL -> if (meters >= 1609) String.format(Locale.US, "%.2f mi", Bearing.metersToMiles(meters)) else "${Bearing.metersToFeet(meters).toInt()} ft"
}
