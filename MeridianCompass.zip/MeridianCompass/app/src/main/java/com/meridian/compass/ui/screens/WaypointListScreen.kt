package com.meridian.compass.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meridian.compass.data.Waypoint
import com.meridian.compass.settings.DistanceUnit
import com.meridian.compass.util.Bearing

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun WaypointListScreen(
    waypoints: List<Waypoint>,
    currentLat: Double?,
    currentLon: Double?,
    distanceUnit: DistanceUnit,
    onBack: () -> Unit,
    onAddNew: () -> Unit,
    onEdit: (Waypoint) -> Unit,
    onDelete: (Waypoint) -> Unit,
    onSelect: (Waypoint) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Waypoints") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddNew) {
                Icon(Icons.Filled.Add, contentDescription = "Add waypoint")
            }
        }
    ) { padding ->
        if (waypoints.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(
                    "No waypoints yet.\nSave your current location with the + button.",
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp, vertical = 8.dp)) {
                items(waypoints, key = { it.id }) { wp ->
                    WaypointRow(
                        waypoint = wp,
                        currentLat = currentLat,
                        currentLon = currentLon,
                        distanceUnit = distanceUnit,
                        onEdit = { onEdit(wp) },
                        onDelete = { onDelete(wp) },
                        onSelect = { onSelect(wp) }
                    )
                }
            }
        }
    }
}

@Composable
private fun WaypointRow(
    waypoint: Waypoint,
    currentLat: Double?,
    currentLon: Double?,
    distanceUnit: DistanceUnit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSelect: () -> Unit
) {
    val distanceText = if (currentLat != null && currentLon != null) {
        val meters = Bearing.distanceMeters(currentLat, currentLon, waypoint.latitude, waypoint.longitude)
        val bearing = Bearing.bearingDegrees(currentLat, currentLon, waypoint.latitude, waypoint.longitude)
        val distStr = when (distanceUnit) {
            DistanceUnit.METRIC -> if (meters >= 1000) "%.2f km".format(meters / 1000) else "${meters.toInt()} m"
            DistanceUnit.IMPERIAL -> if (meters >= 1609) "%.2f mi".format(meters / 1609.344) else "${(meters * 3.28084).toInt()} ft"
        }
        "${bearing.toInt()}°  •  $distStr"
    } else "—"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .then(Modifier),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f).then(
                    Modifier
                )
            ) {
                Icon(Icons.Filled.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(modifier = Modifier.padding(start = 10.dp)) {
                    Text(waypoint.name, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(distanceText, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
            }
            Row {
                IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text(
                "Point compass here",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .clickable { onSelect() },
            )
        }
    }
}
