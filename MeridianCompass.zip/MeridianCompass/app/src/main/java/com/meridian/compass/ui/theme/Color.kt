package com.meridian.compass.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0B1220)
val DeepNavyLight = Color(0xFF141E33)
val AccentTeal = Color(0xFF2FE6C6)
val AccentAmber = Color(0xFFFFB74D)
val OffWhite = Color(0xFFF4F6F8)
val DangerRed = Color(0xFFFF6B6B)
val DialRingLight = Color(0xFFD8DEE8)
val DialRingDark = Color(0xFF23304A)
