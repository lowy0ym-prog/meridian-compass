package com.meridian.compass.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColors = darkColorScheme(
    primary = AccentTeal,
    secondary = AccentAmber,
    background = DeepNavy,
    surface = DeepNavyLight,
    onPrimary = DeepNavy,
    onBackground = OffWhite,
    onSurface = OffWhite,
    error = DangerRed
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF00897B),
    secondary = Color(0xFFEF8A1E),
    background = OffWhite,
    surface = Color(0xFFFFFFFF),
    onPrimary = Color(0xFFFFFFFF),
    onBackground = DeepNavy,
    onSurface = DeepNavy,
    error = DangerRed
)

enum class AppThemeMode { LIGHT, DARK, SYSTEM }

@Composable
fun MeridianTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MeridianTypography,
        content = content
    )
}
